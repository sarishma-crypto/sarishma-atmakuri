from datetime import date, datetime, time, timezone
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

class View(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class Register(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=72)
    name: str = Field(min_length=1, max_length=120)

    @field_validator("password")
    @classmethod
    def bcrypt_limit(cls, value: str):
        if len(value.encode("utf-8")) > 72:
            raise ValueError("Password must be at most 72 UTF-8 bytes")
        return value

class StaffCreate(Register):
    role: str
    specialty: str | None = Field(default=None, max_length=120)

class UserView(View):
    id: int
    email: EmailStr
    role: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ClinicConfig(BaseModel):
    timezone: str

class DoctorView(View):
    id: int
    name: str
    specialty: str

class PatientView(View):
    id: int
    name: str

class ScheduleCreate(BaseModel):
    weekday: int = Field(ge=0, le=6)
    start_time: time
    end_time: time
    slot_minutes: int = Field(ge=5, le=240)

    @model_validator(mode="after")
    def valid_times(self):
        if self.end_time <= self.start_time:
            raise ValueError("End time must be after start time")
        return self

class ScheduleView(View):
    id: int
    doctor_id: int
    weekday: int
    start_time: time
    end_time: time
    slot_minutes: int

class BookingCreate(BaseModel):
    doctor_id: int
    patient_id: int | None = None
    starts_at: datetime
    ends_at: datetime

    @field_validator("starts_at", "ends_at")
    @classmethod
    def utc_time(cls, value: datetime):
        if value.tzinfo is None or value.utcoffset() != timezone.utc.utcoffset(value):
            raise ValueError("Use an explicit UTC timestamp")
        return value.astimezone(timezone.utc).replace(tzinfo=None)

    @model_validator(mode="after")
    def valid_range(self):
        if self.ends_at <= self.starts_at:
            raise ValueError("End must be after start")
        return self

class AppointmentView(View):
    id: int
    doctor_id: int
    patient_id: int
    starts_at: datetime
    ends_at: datetime
    status: str

class Slot(BaseModel):
    starts_at: datetime
    ends_at: datetime

class QueueView(View):
    id: int
    appointment_id: int
    doctor_id: int
    status: str
    checked_in_at: datetime
    called_at: datetime | None

class PrescriptionCreate(BaseModel):
    notes: str = Field(min_length=1, max_length=10000)

class PrescriptionView(View):
    id: int
    appointment_id: int
    doctor_id: int
    notes: str
    created_at: datetime

class AuditView(View):
    id: int
    user_id: int
    action: str
    entity: str
    entity_id: int
    old_value: str | None
    new_value: str | None
    created_at: datetime
