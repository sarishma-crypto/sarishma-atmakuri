import os
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def clinic_zone() -> ZoneInfo:
    name = os.getenv("CLINIC_TIMEZONE", "UTC")
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise RuntimeError(f"Unknown CLINIC_TIMEZONE: {name}") from exc


def clinic_day(value_utc: datetime) -> date:
    return value_utc.replace(tzinfo=timezone.utc).astimezone(clinic_zone()).date()


def clinic_datetime(day: date, clock: time) -> datetime:
    local = datetime.combine(day, clock).replace(tzinfo=clinic_zone())
    utc = local.astimezone(timezone.utc)
    if utc.astimezone(clinic_zone()).replace(tzinfo=None) != local.replace(tzinfo=None):
        raise ValueError("Clinic time does not exist on this date")
    return utc.replace(tzinfo=None)


def clinic_day_bounds(day: date) -> tuple[datetime, datetime]:
    return clinic_datetime(day, time.min), clinic_datetime(day + timedelta(days=1), time.min)
