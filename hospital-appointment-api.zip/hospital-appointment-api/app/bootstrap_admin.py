import sys
from getpass import getpass
from pydantic import EmailStr, TypeAdapter, ValidationError
from sqlalchemy import select
from app.db import SessionLocal
from app.models import AuditLog, User
from app.security import hash_password, secret_key

def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python -m app.bootstrap_admin EMAIL")
    secret_key()
    try:
        email = TypeAdapter(EmailStr).validate_python(sys.argv[1]).lower()
    except ValidationError as exc:
        raise SystemExit(f"Invalid email address: {exc.errors()[0]['msg']}")
    password = getpass("Admin password (12+ characters): ")
    if password != getpass("Confirm password: "):
        raise SystemExit("Passwords do not match")
    if len(password) < 12 or len(password.encode("utf-8")) > 72:
        raise SystemExit("Password must have at least 12 characters and at most 72 UTF-8 bytes")
    with SessionLocal() as db:
        if db.scalar(select(User.id).where(User.email == email)):
            raise SystemExit("Email already exists")
        user = User(email=email, password_hash=hash_password(password), role="ADMIN")
        db.add(user)
        db.flush()
        db.add(AuditLog(user_id=user.id, action="BOOTSTRAP", entity="user", entity_id=user.id,
                        new_value='{"role": "ADMIN"}'))
        db.commit()
    print("Admin created")

if __name__ == "__main__":
    main()
