const $ = (selector) => document.querySelector(selector);
const state = { token: sessionStorage.getItem('careflow_token'), user: null, section: '', doctors: [], patients: [], myDoctor: null, timezone: 'UTC' };
const content = $('#content');

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
function notice(message, error = false) {
  const box = $('#notice');
  box.textContent = message;
  box.classList.toggle('error', error);
  box.hidden = false;
  clearTimeout(notice.timer);
  notice.timer = setTimeout(() => box.hidden = true, 5000);
}
async function api(path, { method = 'GET', body, form = false } = {}) {
  const headers = {};
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (body && !form) headers['Content-Type'] = 'application/json';
  const response = await fetch(path, { method, headers, body: body ? (form ? new URLSearchParams(body) : JSON.stringify(body)) : undefined });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = data?.detail;
    const message = Array.isArray(detail) ? detail.map(item => item.msg).join('; ') : (typeof detail === 'string' ? detail : `Request failed (${response.status})`);
    if (response.status === 401 && state.user) signOut();
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return data;
}
function clinicTime(value) {
  if (!value) return '';
  const date = new Date(value.endsWith('Z') ? value : `${value}Z`);
  return new Intl.DateTimeFormat('en-GB', { timeZone: state.timezone, day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).format(date) + ` ${state.timezone}`;
}
function slotTime(value) { return new Intl.DateTimeFormat('en-GB', { timeZone: state.timezone, hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(`${value}Z`)); }
function clinicDate(value = new Date()) {
  const date = value instanceof Date ? value : new Date(`${value}Z`);
  const parts = new Intl.DateTimeFormat('en-GB', {timeZone: state.timezone, year:'numeric', month:'2-digit', day:'2-digit'}).formatToParts(date);
  const part = type => parts.find(item => item.type === type).value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}
function dayName(number) { return ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'][Number(number)]; }
function badge(value) { return `<span class="badge ${escapeHtml(value)}">${escapeHtml(value.replaceAll('_', ' '))}</span>`; }
function empty(title, text) { return `<div class="empty"><strong>${escapeHtml(title)}</strong>${escapeHtml(text)}</div>`; }
function doctorName(id) { return state.doctors.find(item => item.id === id)?.name || `Doctor #${id}`; }
function patientName(id) { return state.patients.find(item => item.id === id)?.name || `Patient #${id}`; }
function doctorOptions() { return state.doctors.map(item => `<option value="${item.id}">${escapeHtml(item.name)} · ${escapeHtml(item.specialty)}</option>`).join(''); }
function field(label, input, extra = '') { return `<label class="field ${extra}">${label}${input}</label>`; }
function section(title, subtitle, body) { return `<section class="panel"><div class="section-head"><div><h2>${title}</h2><p>${subtitle}</p></div></div>${body}</section>`; }

function showAuth(tab = 'login') {
  window.scrollTo(0, 0);
  $('#auth-view').hidden = false;
  $('#workspace').hidden = true;
  $('#account').hidden = true;
  $('#logout').hidden = true;
  $('#login-form').hidden = tab !== 'login';
  $('#register-form').hidden = tab !== 'register';
  $('#login-tab').classList.toggle('active', tab === 'login');
  $('#register-tab').classList.toggle('active', tab === 'register');
  $('#login-tab').setAttribute('aria-selected', tab === 'login');
  $('#register-tab').setAttribute('aria-selected', tab === 'register');
}
function signOut() {
  state.token = null; state.user = null; state.section = '';
  sessionStorage.removeItem('careflow_token');
  showAuth();
}
async function signIn(email, password) {
  const result = await api('/auth/login', { method: 'POST', body: { username: email, password }, form: true });
  state.token = result.access_token;
  sessionStorage.setItem('careflow_token', state.token);
  await enterWorkspace();
}
async function enterWorkspace() {
  state.timezone = (await api('/config')).timezone;
  state.user = await api('/auth/me');
  state.doctors = await api('/doctors?limit=100');
  state.patients = ['ADMIN', 'RECEPTIONIST', 'DOCTOR'].includes(state.user.role) ? await api('/patients?limit=100') : [];
  state.myDoctor = state.user.role === 'DOCTOR' ? await api('/doctors/me') : null;
  $('#auth-view').hidden = true;
  $('#workspace').hidden = false;
  $('#account').hidden = false;
  $('#logout').hidden = false;
  $('#account').textContent = state.user.email;
  $('#time-note').textContent = `Clinic time · ${state.timezone}`;
  window.scrollTo(0, 0);
  const role = state.user.role;
  const labels = { PATIENT: ['Patient workspace', 'Your care, in one place', 'Book a visit and follow your appointments.'], ADMIN: ['Clinic administration', 'Keep the day moving', 'Set up doctors and schedules, then manage visits.'], RECEPTIONIST: ['Reception desk', 'A clear view of today', 'Check patients in and guide the queue.'], DOCTOR: ['Doctor workspace', 'Ready for the next patient', 'See your appointments and move the queue forward.'] };
  $('#role-label').textContent = labels[role][0];
  $('#page-title').textContent = labels[role][1];
  $('#page-description').textContent = labels[role][2];
  state.section = {PATIENT:'book', ADMIN:'setup', RECEPTIONIST:'appointments', DOCTOR:'queue'}[role];
  renderNav();
  await renderSection();
}
function renderNav() {
  const items = state.user.role === 'PATIENT' ? [['book','Book a visit'],['appointments','My appointments']]
    : state.user.role === 'DOCTOR' ? [['queue','My queue'],['appointments','My appointments']]
    : state.user.role === 'RECEPTIONIST' ? [['book','Book for patient'],['appointments','Appointments'],['queue','Live queue']]
    : [['setup','Clinic setup'],['book','Book for patient'],['appointments','Appointments'],['queue','Live queue'],['audit','Audit log']];
  $('#nav').innerHTML = items.map(([id,label]) => `<button type="button" data-nav="${id}" class="${state.section === id ? 'active' : ''}" aria-current="${state.section === id ? 'page' : 'false'}">${label}</button>`).join('');
}
async function renderSection() {
  content.innerHTML = '<div class="empty">Loading your workspace…</div>';
  try {
    if (state.section === 'book') await renderBooking();
    if (state.section === 'appointments') await renderAppointments();
    if (state.section === 'queue') await renderQueue();
    if (state.section === 'setup') await renderSetup();
    if (state.section === 'audit') await renderAudit();
  } catch (error) { content.innerHTML = empty('Could not load this section', error.message); notice(error.message, true); }
}
async function renderBooking() {
  const forPatient = state.user.role !== 'PATIENT';
  const patientSelect = forPatient ? field('Patient', `<select name="patient_id" required>${state.patients.map(item => `<option value="${item.id}">${escapeHtml(item.name)} · #${item.id}</option>`).join('')}</select>`) : '';
  content.innerHTML = section('Find an appointment', 'Choose a doctor and date to see open times.',
    `<form id="slot-search" class="toolbar">${patientSelect}${field('Doctor', `<select name="doctor_id" required>${doctorOptions()}</select>`)}${field('Date', `<input name="day" type="date" min="${clinicDate()}" value="${clinicDate()}" required>`)}<button class="primary-button" type="submit">Show available times</button></form><p class="inline-note" style="margin-top:16px">Times are shown in ${escapeHtml(state.timezone)}. Selecting a time books it immediately.</p>`);
  content.insertAdjacentHTML('beforeend', `<section class="panel"><div class="section-head"><div><h2>Available times</h2><p>Pick the time that works for you.</p></div></div><div id="slots">${empty('Choose a doctor and date', 'Available appointments will appear here.')}</div></section>`);
  if (!state.doctors.length) $('#slots').innerHTML = empty('No doctors added yet', 'Please ask the clinic to add a doctor and schedule.');
  if (forPatient && !state.patients.length) $('#slots').innerHTML = empty('No patients yet', 'A patient must register before staff can book for them.');
}
async function renderAppointments() {
  const appointments = await api('/appointments?limit=100&sort=asc');
  const rows = appointments.map(item => {
    const title = state.user.role === 'PATIENT' ? doctorName(item.doctor_id) : `${patientName(item.patient_id)} with ${doctorName(item.doctor_id)}`;
    const actions = [];
    if (item.status === 'BOOKED' && ['PATIENT','RECEPTIONIST','ADMIN'].includes(state.user.role)) actions.push(`<button class="danger-button" data-action="cancel" data-id="${item.id}">Cancel</button>`);
    if (item.status === 'BOOKED' && ['RECEPTIONIST','ADMIN'].includes(state.user.role) && clinicDate(item.starts_at) === clinicDate()) actions.push(`<button class="secondary-button" data-action="checkin" data-id="${item.id}">Check in</button>`);
    if (item.status === 'COMPLETED' && ['PATIENT','DOCTOR','ADMIN'].includes(state.user.role)) actions.push(`<button class="secondary-button" data-action="prescription" data-id="${item.id}">${state.user.role === 'DOCTOR' ? 'Prescription' : 'View prescription'}</button>`);
    return `<div class="list-row"><div><p class="list-title">${escapeHtml(title)}</p><p class="list-meta">${clinicTime(item.starts_at)} · Appointment #${item.id}</p></div><div class="row-actions">${badge(item.status)}${actions.join('')}</div></div>`;
  }).join('');
  content.innerHTML = section(state.user.role === 'PATIENT' ? 'Your appointments' : 'Appointments', 'Upcoming and past bookings, ordered by time.',
    appointments.length ? `<div class="list">${rows}</div>` : empty('No appointments yet', state.user.role === 'PATIENT' ? 'Book your first visit to see it here.' : 'Bookings will appear here when patients reserve a time.'));
}
async function renderQueue() {
  const doctorId = state.user.role === 'DOCTOR' ? state.myDoctor.id : Number(sessionStorage.getItem('careflow_queue_doctor')) || state.doctors[0]?.id;
  if (!doctorId) { content.innerHTML = section('Live queue', 'Patients checked in for a doctor appear here.', empty('No doctors added yet', 'Add a doctor in Clinic setup first.')); return; }
  const entries = await api(`/queue/${doctorId}`);
  const appointments = await api('/appointments?limit=100');
  const appointmentById = new Map(appointments.map(item => [item.id, item]));
  const chooser = state.user.role === 'DOCTOR' ? '' : `<label class="field">Doctor<select id="queue-doctor">${state.doctors.map(item => `<option value="${item.id}" ${item.id === doctorId ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}</select></label>`;
  const rows = entries.filter(item => item.status !== 'DONE').map(item => {
    const appointment = appointmentById.get(item.appointment_id);
    const patient = appointment ? patientName(appointment.patient_id) : `Appointment #${item.appointment_id}`;
    const actions = item.status === 'CALLED' && ['DOCTOR','ADMIN'].includes(state.user.role) ? `<button class="secondary-button" data-action="complete" data-id="${item.id}">Complete visit</button>` : '';
    return `<div class="list-row"><div><p class="list-title">${escapeHtml(patient)}</p><p class="list-meta">Checked in ${clinicTime(item.checked_in_at)} · Appointment #${item.appointment_id}</p></div><div class="row-actions">${badge(item.status)}${actions}</div></div>`;
  }).join('');
  const canCall = entries.some(item => item.status === 'WAITING') && !entries.some(item => item.status === 'CALLED');
  content.innerHTML = section('Live queue', 'Today’s check-ins are called in arrival order.', `<div class="section-head"><div class="toolbar">${chooser}</div><button class="primary-button" data-action="callnext" data-id="${doctorId}" ${canCall ? '' : 'disabled'}>Call next patient</button></div>${rows ? `<div class="list">${rows}</div>` : empty('No one waiting', 'Checked-in patients will appear here.')}`);
}
async function renderSetup() {
  const schedules = await api('/admin/schedules');
  const doctorRows = state.doctors.map(doctor => {
    const hours = schedules.filter(item => item.doctor_id === doctor.id)
      .map(item => `${dayName(item.weekday)} ${item.start_time.slice(0,5)}–${item.end_time.slice(0,5)} · ${item.slot_minutes} min`);
    return `<div class="list-row"><div><p class="list-title">${escapeHtml(doctor.name)}</p><p class="list-meta">${escapeHtml(doctor.specialty)} · Doctor #${doctor.id}</p><p class="list-meta">${hours.length ? escapeHtml(hours.join(' · ')) : 'No schedule yet'}</p></div></div>`;
  }).join('');
  const staffForm = `<form id="staff-form" class="form-grid">
    ${field('Full name','<input name="name" required maxlength="120">')}
    ${field('Email','<input name="email" type="email" required>')}
    ${field('Role','<select name="role"><option value="DOCTOR">Doctor</option><option value="RECEPTIONIST">Receptionist</option></select>')}
    ${field('Specialty (for doctors)','<input name="specialty" maxlength="120" required>')}
    ${field('Temporary password <small>12+ characters</small>','<input name="password" type="password" minlength="12" required>','full')}
    <div class="form-actions full"><button class="primary-button" type="submit">Add staff member</button></div>
  </form>`;
  const scheduleForm = `<form id="schedule-form" class="form-grid">
    ${field('Doctor',`<select name="doctor_id" required>${doctorOptions()}</select>`)}
    ${field('Day','<select name="weekday"><option value="0">Monday</option><option value="1">Tuesday</option><option value="2">Wednesday</option><option value="3">Thursday</option><option value="4">Friday</option><option value="5">Saturday</option><option value="6">Sunday</option></select>')}
    ${field('Start time','<input name="start_time" type="time" required value="09:00">')}
    ${field('End time','<input name="end_time" type="time" required value="17:00">')}
    ${field('Appointment length','<select name="slot_minutes"><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="45">45 minutes</option><option value="60">60 minutes</option></select>')}
    <div class="form-actions"><button class="primary-button" type="submit" ${state.doctors.length ? '' : 'disabled'}>Save schedule</button></div>
  </form>`;
  content.innerHTML = section('Add a doctor or receptionist', 'Staff receive their own login and role.', staffForm) +
    `<div class="grid-two">${section('Set doctor hours', `Weekly hours in ${escapeHtml(state.timezone)}.`, scheduleForm)}${section('Clinic doctors', 'Doctors available for scheduling.', doctorRows ? `<div class="list">${doctorRows}</div>` : empty('No doctors yet','Add a doctor to set their hours.'))}</div>`;
}

async function renderAudit() {
  const logs = await api('/admin/audit-logs?limit=100');
  const rows = logs.map(item => `<div class="list-row"><div><p class="list-title">${escapeHtml(item.action.replaceAll('_',' '))} · ${escapeHtml(item.entity)} #${item.entity_id}</p><p class="list-meta">${clinicTime(item.created_at)} · User #${item.user_id}</p></div></div>`).join('');
  content.innerHTML = section('Audit log', 'Recent state changes are kept as append-only records.', rows ? `<div class="list">${rows}</div>` : empty('No changes yet','Actions will appear here as the clinic starts using the app.'));
}

function showPrescriptionForm(appointmentId) {
  content.innerHTML = section('Write prescription', `Completed appointment #${appointmentId}`,
    `<form id="prescription-form" class="form-stack"><input type="hidden" name="appointment_id" value="${appointmentId}">${field('Prescription notes','<textarea name="notes" maxlength="10000" required placeholder="Enter instructions for the patient"></textarea>')}<div class="row-actions"><button class="primary-button" type="submit">Save prescription</button><button class="secondary-button" type="button" data-action="back">Back to appointments</button></div></form>`);
}

$('#login-tab').addEventListener('click', () => showAuth('login'));
$('#register-tab').addEventListener('click', () => showAuth('register'));
$('#logout').addEventListener('click', signOut);
$('#login-form').addEventListener('submit', async event => {
  event.preventDefault(); const data = new FormData(event.currentTarget);
  const button = event.currentTarget.querySelector('button[type=submit]'); button.disabled = true;
  try { await signIn(data.get('email'), data.get('password')); notice('Signed in successfully.'); }
  catch (error) { notice(error.message, true); }
  finally { button.disabled = false; }
});
$('#register-form').addEventListener('submit', async event => {
  event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget));
  const button = event.currentTarget.querySelector('button[type=submit]'); button.disabled = true;
  try { await api('/auth/register', {method:'POST', body:data}); await signIn(data.email, data.password); notice('Your account is ready.'); }
  catch (error) { notice(error.message, true); }
  finally { button.disabled = false; }
});
$('#nav').addEventListener('click', async event => {
  const button = event.target.closest('[data-nav]'); if (!button) return;
  state.section = button.dataset.nav; renderNav(); await renderSection();
});
content.addEventListener('change', async event => {
  if (event.target.id === 'queue-doctor') { sessionStorage.setItem('careflow_queue_doctor', event.target.value); await renderQueue(); }
  if (event.target.name === 'role' && event.target.closest('#staff-form')) {
    const specialty = $('#staff-form [name=specialty]'); specialty.required = event.target.value === 'DOCTOR'; specialty.disabled = !specialty.required;
  }
});
content.addEventListener('submit', async event => {
  event.preventDefault(); const form = event.target; const data = Object.fromEntries(new FormData(form));
  const button = form.querySelector('button[type=submit]'); if (button) button.disabled = true;
  try {
    if (form.id === 'slot-search') {
      const slots = await api(`/doctors/${data.doctor_id}/available-slots?day=${encodeURIComponent(data.day)}`);
      $('#slots').innerHTML = slots.length ? `<div class="slot-grid">${slots.map(slot => `<button class="slot-button" type="button" data-action="book" data-doctor="${data.doctor_id}" ${data.patient_id ? `data-patient="${data.patient_id}"` : ''} data-start="${escapeHtml(slot.starts_at)}" data-end="${escapeHtml(slot.ends_at)}">${escapeHtml(slotTime(slot.starts_at))}</button>`).join('')}</div>` : empty('No open times', 'Try another date or doctor.');
    }
    if (form.id === 'staff-form') {
      if (data.role !== 'DOCTOR') data.specialty = null;
      await api('/admin/staff', {method:'POST', body:data}); state.doctors = await api('/doctors?limit=100'); notice('Staff member added.'); await renderSetup();
    }
    if (form.id === 'schedule-form') {
      const doctorId = data.doctor_id; delete data.doctor_id;
      data.weekday = Number(data.weekday); data.slot_minutes = Number(data.slot_minutes);
      await api(`/admin/doctors/${doctorId}/schedules`, {method:'POST', body:data}); notice('Weekly schedule saved.'); await renderSetup();
    }
    if (form.id === 'prescription-form') {
      await api(`/appointments/${data.appointment_id}/prescription`, {method:'POST', body:{notes:data.notes}}); notice('Prescription saved.'); state.section = 'appointments'; renderNav(); await renderAppointments();
    }
  } catch (error) { notice(error.message, true); }
  finally { if (button?.isConnected) button.disabled = false; }
});
content.addEventListener('click', async event => {
  const button = event.target.closest('[data-action]'); if (!button) return;
  button.disabled = true;
  try {
    const {action,id} = button.dataset;
    if (action === 'book') {
      const payload = {doctor_id:Number(button.dataset.doctor), starts_at:`${button.dataset.start}Z`, ends_at:`${button.dataset.end}Z`};
      if (button.dataset.patient) payload.patient_id = Number(button.dataset.patient);
      await api('/appointments', {method:'POST', body:payload});
      notice('Appointment booked.'); state.section = 'appointments'; renderNav(); await renderAppointments();
    }
    if (action === 'cancel') { if (!window.confirm('Cancel this appointment?')) { button.disabled = false; return; } await api(`/appointments/${id}/cancel`, {method:'POST'}); notice('Appointment cancelled.'); await renderAppointments(); }
    if (action === 'checkin') { await api(`/appointments/${id}/check-in`, {method:'POST'}); notice('Patient checked in.'); await renderAppointments(); }
    if (action === 'callnext') { await api(`/queue/${id}/call-next`, {method:'POST'}); notice('Next patient called.'); await renderQueue(); }
    if (action === 'complete') {
      const entry = await api(`/queue/${id}/complete`, {method:'POST'}); notice('Visit completed.');
      if (state.user.role === 'DOCTOR') showPrescriptionForm(entry.appointment_id);
      else await renderQueue();
    }
    if (action === 'prescription') {
      try {
        const prescription = await api(`/appointments/${id}/prescription`);
        content.innerHTML = section('Prescription', `Appointment #${id}`, `<p class="prescription-notes">${escapeHtml(prescription.notes)}</p><button class="secondary-button" data-action="back">Back to appointments</button>`);
      } catch (error) {
        if (state.user.role === 'DOCTOR' && error.status === 404) showPrescriptionForm(id);
        else throw error;
      }
    }
    if (action === 'back') await renderAppointments();
  } catch (error) { notice(error.message, true); if (button.isConnected) button.disabled = false; }
});
(async () => {
  if (!state.token) { showAuth(); return; }
  try { await enterWorkspace(); }
  catch { signOut(); }
})();
