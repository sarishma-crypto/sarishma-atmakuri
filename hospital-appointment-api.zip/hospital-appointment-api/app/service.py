import json
import logging
from datetime import date, datetime, timedelta, timezone
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.clinic_time import clinic_datetime, clinic_day, clinic_day_bounds, clinic_zone
from app.models import Appointment, AuditLog, Doctor, Patient, QueueEntry, Schedule, utc_now
from app.schemas import BookingCreate, Slot

log = logging.getLogger(__name__)

def audit(db: Session, user_id: int, action: str, entity: str, entity_id: int, old=None, new=None):
    db.add(AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id,
                    old_value=json.dumps(old) if old is not None else None,
                    new_value=json.dumps(new) if new is not None else None))

def begin_write(db: Session):
    # SQLite has no row locks; reserve the writer before reading business state.
    db.rollback()
    db.connection().exec_driver_sql("BEGIN IMMEDIATE")

def schedule_for(db: Session, doctor_id: int, start: datetime, end: datetime):
    local_start = start.replace(tzinfo=timezone.utc).astimezone(clinic_zone())
    local_end = end.replace(tzinfo=timezone.utc).astimezone(clinic_zone())
    if local_start.date() != local_end.date():
        return None
    schedules = db.scalars(select(Schedule).where(Schedule.doctor_id == doctor_id,
                                                  Schedule.weekday == local_start.weekday())).all()
    for schedule in schedules:
        day_start = datetime.combine(local_start.date(), schedule.start_time)
        day_end = datetime.combine(local_start.date(), schedule.end_time)
        minutes = schedule.slot_minutes
        local_naive = local_start.replace(tzinfo=None)
        if day_start <= local_naive and local_end.replace(tzinfo=None) <= day_end and end - start == timedelta(minutes=minutes) and \
                (local_naive - day_start).total_seconds() % (minutes * 60) == 0:
            return schedule
    return None

def overlapping(db: Session, doctor_id: int, start: datetime, end: datetime):
    return db.scalar(select(Appointment.id).where(Appointment.doctor_id == doctor_id,
        Appointment.status != "CANCELLED", Appointment.starts_at < end,
        Appointment.ends_at > start).limit(1)) is not None

def book(db: Session, data: BookingCreate, patient_id: int, user_id: int) -> Appointment:
    begin_write(db)
    if data.starts_at <= utc_now():
        raise HTTPException(400, "Appointment must be in the future")
    if db.get(Doctor, data.doctor_id) is None or db.get(Patient, patient_id) is None:
        raise HTTPException(404, "Doctor or patient not found")
    if schedule_for(db, data.doctor_id, data.starts_at, data.ends_at) is None:
        raise HTTPException(400, "Appointment must match an available schedule slot")
    if overlapping(db, data.doctor_id, data.starts_at, data.ends_at):
        raise HTTPException(409, "Doctor already has an appointment in this slot")
    appointment = Appointment(doctor_id=data.doctor_id, patient_id=patient_id,
                              starts_at=data.starts_at, ends_at=data.ends_at, status="BOOKED")
    db.add(appointment)
    db.flush()
    audit(db, user_id, "BOOK", "appointment", appointment.id, new={"status": "BOOKED"})
    db.commit()
    log.info("appointment_booked id=%s doctor_id=%s", appointment.id, data.doctor_id)
    return appointment

def available_slots(db: Session, doctor_id: int, day: date) -> list[Slot]:
    if db.get(Doctor, doctor_id) is None:
        raise HTTPException(404, "Doctor not found")
    schedules = db.scalars(select(Schedule).where(Schedule.doctor_id == doctor_id,
                                                  Schedule.weekday == day.weekday()).order_by(Schedule.start_time)).all()
    result = []
    for schedule in schedules:
        start = datetime.combine(day, schedule.start_time)
        limit = datetime.combine(day, schedule.end_time)
        while start + timedelta(minutes=schedule.slot_minutes) <= limit:
            end = start + timedelta(minutes=schedule.slot_minutes)
            try:
                start_utc = clinic_datetime(day, start.time())
                end_utc = clinic_datetime(day, end.time())
            except ValueError:
                start = end
                continue
            if start_utc > utc_now() and end_utc - start_utc == timedelta(minutes=schedule.slot_minutes) and \
                    not overlapping(db, doctor_id, start_utc, end_utc):
                result.append(Slot(starts_at=start_utc, ends_at=end_utc))
            start = end
    return result

def check_in(db: Session, appointment_id: int, user_id: int) -> QueueEntry:
    begin_write(db)
    appointment = db.get(Appointment, appointment_id)
    if appointment is None:
        raise HTTPException(404, "Appointment not found")
    if appointment.status != "BOOKED":
        raise HTTPException(409, "Only booked appointments can check in")
    if db.scalar(select(QueueEntry.id).where(QueueEntry.appointment_id == appointment_id)):
        raise HTTPException(409, "Appointment is already checked in")
    if clinic_day(appointment.starts_at) != clinic_day(utc_now()):
        raise HTTPException(400, "Check-in is allowed only on the appointment day")
    entry = QueueEntry(appointment_id=appointment.id, doctor_id=appointment.doctor_id, status="WAITING")
    db.add(entry)
    db.flush()
    audit(db, user_id, "CHECK_IN", "queue_entry", entry.id, new={"status": "WAITING"})
    db.commit()
    return entry

def call_next(db: Session, doctor_id: int, user_id: int) -> QueueEntry:
    begin_write(db)
    day_start, day_end = clinic_day_bounds(clinic_day(utc_now()))
    if db.scalar(select(QueueEntry.id).where(QueueEntry.doctor_id == doctor_id,
                                             QueueEntry.status == "CALLED",
                                             QueueEntry.checked_in_at >= day_start,
                                             QueueEntry.checked_in_at < day_end).limit(1)):
        raise HTTPException(409, "Complete the current patient before calling next")
    entry = db.scalar(select(QueueEntry).where(QueueEntry.doctor_id == doctor_id,
        QueueEntry.status == "WAITING", QueueEntry.checked_in_at >= day_start,
        QueueEntry.checked_in_at < day_end).order_by(QueueEntry.checked_in_at, QueueEntry.id).limit(1))
    if entry is None:
        raise HTTPException(404, "No waiting patients")
    entry.status = "CALLED"
    entry.called_at = utc_now()
    audit(db, user_id, "CALL_NEXT", "queue_entry", entry.id,
          old={"status": "WAITING"}, new={"status": "CALLED"})
    db.commit()
    log.info("queue_called entry_id=%s doctor_id=%s", entry.id, doctor_id)
    return entry
