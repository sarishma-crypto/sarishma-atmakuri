import logging
from contextlib import asynccontextmanager
from datetime import date
from pathlib import Path
from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.db import get_db
from app.clinic_time import clinic_day, clinic_day_bounds, clinic_zone
from app.models import Appointment, AuditLog, Doctor, Patient, Prescription, QueueEntry, Schedule, User, utc_now
from app.schemas import (AppointmentView, AuditView, BookingCreate, DoctorView, PrescriptionCreate,
                         PrescriptionView, QueueView, Register, ScheduleCreate, ScheduleView,
                         Slot, StaffCreate, Token, UserView, PatientView, ClinicConfig)
from app.security import current_user, hash_password, make_token, roles, secret_key, verify_password
from app.service import audit, available_slots, begin_write, book, call_next, check_in

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
@asynccontextmanager
async def lifespan(_app: FastAPI):
    secret_key()
    clinic_zone()
    yield

app = FastAPI(title="Hospital Appointment & Queue API", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=Path(__file__).resolve().parent / "static"), name="static")

@app.get("/", include_in_schema=False)
def home():
    return RedirectResponse("/static/index.html")

@app.get("/config", response_model=ClinicConfig)
def clinic_config():
    return ClinicConfig(timezone=clinic_zone().key)

@app.get("/auth/me", response_model=UserView)
def me(user: User = Depends(current_user)):
    return user

@app.post("/auth/register", response_model=UserView, status_code=201)
def register(data: Register, db: Session = Depends(get_db)):
    user = User(email=data.email.lower(), password_hash=hash_password(data.password), role="PATIENT")
    db.add(user)
    try:
        db.flush()
        patient = Patient(user_id=user.id, name=data.name)
        db.add(patient)
        db.flush()
        audit(db, user.id, "REGISTER", "patient", patient.id, new={"name": data.name})
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Email already registered")
    return user

@app.post("/auth/login", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username.lower()))
    if not user or not user.active or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")
    return Token(access_token=make_token(user))

@app.post("/admin/staff", response_model=UserView, status_code=201)
def create_staff(data: StaffCreate, db: Session = Depends(get_db), user: User = Depends(roles("ADMIN"))):
    if data.role not in ("DOCTOR", "RECEPTIONIST") or (data.role == "DOCTOR" and not data.specialty):
        raise HTTPException(400, "Role must be DOCTOR or RECEPTIONIST; doctors need a specialty")
    actor_id = user.id
    staff = User(email=data.email.lower(), password_hash=hash_password(data.password), role=data.role)
    db.add(staff)
    try:
        db.flush()
        if data.role == "DOCTOR":
            doctor = Doctor(user_id=staff.id, name=data.name, specialty=data.specialty)
            db.add(doctor)
            db.flush()
            audit(db, actor_id, "CREATE", "doctor", doctor.id, new={"name": data.name, "specialty": data.specialty})
        else:
            audit(db, actor_id, "CREATE", "user", staff.id, new={"role": data.role})
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Email already registered")
    return staff

@app.get("/doctors", response_model=list[DoctorView])
def list_doctors(db: Session = Depends(get_db), _: User = Depends(current_user),
                 offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=100),
                 specialty: str | None = None):
    query = select(Doctor).order_by(Doctor.id).offset(offset).limit(limit)
    if specialty:
        query = select(Doctor).where(Doctor.specialty == specialty).order_by(Doctor.id).offset(offset).limit(limit)
    return db.scalars(query).all()

@app.get("/doctors/me", response_model=DoctorView)
def my_doctor(db: Session = Depends(get_db), user: User = Depends(roles("DOCTOR"))):
    return db.scalar(select(Doctor).where(Doctor.user_id == user.id))

@app.get("/patients", response_model=list[PatientView])
def list_patients(db: Session = Depends(get_db), user: User = Depends(roles("ADMIN", "RECEPTIONIST", "DOCTOR")),
                  offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=100)):
    query = select(Patient)
    if user.role == "DOCTOR":
        doctor_id = db.scalar(select(Doctor.id).where(Doctor.user_id == user.id))
        query = query.where(Patient.id.in_(select(Appointment.patient_id).where(Appointment.doctor_id == doctor_id)))
    return db.scalars(query.order_by(Patient.id).offset(offset).limit(limit)).all()

@app.get("/doctors/{doctor_id}/schedules", response_model=list[ScheduleView])
def list_schedules(doctor_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    if db.get(Doctor, doctor_id) is None:
        raise HTTPException(404, "Doctor not found")
    return db.scalars(select(Schedule).where(Schedule.doctor_id == doctor_id).order_by(Schedule.weekday, Schedule.start_time)).all()

@app.get("/admin/schedules", response_model=list[ScheduleView])
def all_schedules(db: Session = Depends(get_db), _: User = Depends(roles("ADMIN"))):
    return db.scalars(select(Schedule).order_by(Schedule.doctor_id, Schedule.weekday, Schedule.start_time)).all()

@app.post("/admin/doctors/{doctor_id}/schedules", response_model=ScheduleView, status_code=201)
def add_schedule(doctor_id: int, data: ScheduleCreate, db: Session = Depends(get_db),
                 user: User = Depends(roles("ADMIN"))):
    actor_id = user.id
    begin_write(db)
    if db.get(Doctor, doctor_id) is None:
        raise HTTPException(404, "Doctor not found")
    conflict = db.scalar(select(Schedule.id).where(Schedule.doctor_id == doctor_id,
        Schedule.weekday == data.weekday, Schedule.start_time < data.end_time,
        Schedule.end_time > data.start_time).limit(1))
    if conflict:
        raise HTTPException(409, "Schedule overlaps an existing schedule")
    schedule = Schedule(doctor_id=doctor_id, **data.model_dump())
    db.add(schedule)
    db.flush()
    audit(db, actor_id, "CREATE", "schedule", schedule.id, new=data.model_dump(mode="json"))
    db.commit()
    return schedule

@app.get("/doctors/{doctor_id}/available-slots", response_model=list[Slot])
def slots(doctor_id: int, day: date, db: Session = Depends(get_db), _: User = Depends(current_user)):
    return available_slots(db, doctor_id, day)

@app.post("/appointments", response_model=AppointmentView, status_code=201)
def create_appointment(data: BookingCreate, db: Session = Depends(get_db),
                       user: User = Depends(roles("PATIENT", "RECEPTIONIST", "ADMIN"))):
    actor_id, role = user.id, user.role
    if role == "PATIENT":
        patient = db.scalar(select(Patient).where(Patient.user_id == actor_id))
        if data.patient_id is not None and data.patient_id != patient.id:
            raise HTTPException(403, "Cannot book for another patient")
        patient_id = patient.id
    else:
        if data.patient_id is None:
            raise HTTPException(400, "patient_id is required for staff booking")
        patient_id = data.patient_id
    return book(db, data, patient_id, actor_id)

@app.get("/appointments", response_model=list[AppointmentView])
def list_appointments(db: Session = Depends(get_db), user: User = Depends(current_user),
                      status: str | None = None, offset: int = Query(0, ge=0),
                      limit: int = Query(50, ge=1, le=100), sort: str = "asc"):
    if sort not in ("asc", "desc"):
        raise HTTPException(400, "sort must be asc or desc")
    query = select(Appointment)
    if user.role == "PATIENT":
        patient_id = db.scalar(select(Patient.id).where(Patient.user_id == user.id))
        query = query.where(Appointment.patient_id == patient_id)
    elif user.role == "DOCTOR":
        doctor_id = db.scalar(select(Doctor.id).where(Doctor.user_id == user.id))
        query = query.where(Appointment.doctor_id == doctor_id)
    if status:
        query = query.where(Appointment.status == status.upper())
    order = Appointment.starts_at.desc() if sort == "desc" else Appointment.starts_at.asc()
    return db.scalars(query.order_by(order, Appointment.id).offset(offset).limit(limit)).all()

@app.post("/appointments/{appointment_id}/cancel", response_model=AppointmentView)
def cancel(appointment_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    actor_id, role = user.id, user.role
    begin_write(db)
    appointment = db.get(Appointment, appointment_id)
    if appointment is None:
        raise HTTPException(404, "Appointment not found")
    if role == "PATIENT":
        patient_id = db.scalar(select(Patient.id).where(Patient.user_id == actor_id))
        if appointment.patient_id != patient_id:
            raise HTTPException(403, "Cannot cancel another patient's appointment")
    elif role not in ("RECEPTIONIST", "ADMIN"):
        raise HTTPException(403, "Insufficient permissions")
    if appointment.status != "BOOKED" or db.scalar(select(QueueEntry.id).where(QueueEntry.appointment_id == appointment_id)):
        raise HTTPException(409, "Only a booking without check-in can be cancelled")
    appointment.status = "CANCELLED"
    audit(db, actor_id, "CANCEL", "appointment", appointment.id,
          old={"status": "BOOKED"}, new={"status": "CANCELLED"})
    db.commit()
    return appointment

@app.post("/appointments/{appointment_id}/check-in", response_model=QueueView, status_code=201)
def check_in_route(appointment_id: int, db: Session = Depends(get_db),
                   user: User = Depends(roles("RECEPTIONIST", "ADMIN"))):
    return check_in(db, appointment_id, user.id)

@app.get("/queue/{doctor_id}", response_model=list[QueueView])
def view_queue(doctor_id: int, db: Session = Depends(get_db),
               user: User = Depends(roles("DOCTOR", "RECEPTIONIST", "ADMIN")),
               status: str | None = None):
    if user.role == "DOCTOR" and db.scalar(select(Doctor.id).where(Doctor.user_id == user.id)) != doctor_id:
        raise HTTPException(403, "Cannot view another doctor's queue")
    day_start, day_end = clinic_day_bounds(clinic_day(utc_now()))
    query = select(QueueEntry).where(QueueEntry.doctor_id == doctor_id,
        QueueEntry.checked_in_at >= day_start, QueueEntry.checked_in_at < day_end)
    if status:
        query = query.where(QueueEntry.status == status.upper())
    return db.scalars(query.order_by(QueueEntry.checked_in_at, QueueEntry.id)).all()

@app.post("/queue/{doctor_id}/call-next", response_model=QueueView)
def call_next_route(doctor_id: int, db: Session = Depends(get_db),
                    user: User = Depends(roles("DOCTOR", "RECEPTIONIST", "ADMIN"))):
    if user.role == "DOCTOR" and db.scalar(select(Doctor.id).where(Doctor.user_id == user.id)) != doctor_id:
        raise HTTPException(403, "Cannot call another doctor's queue")
    return call_next(db, doctor_id, user.id)

@app.post("/queue/{entry_id}/complete", response_model=QueueView)
def complete(entry_id: int, db: Session = Depends(get_db), user: User = Depends(roles("DOCTOR", "ADMIN"))):
    actor_id, role = user.id, user.role
    begin_write(db)
    entry = db.get(QueueEntry, entry_id)
    if entry is None:
        raise HTTPException(404, "Queue entry not found")
    if role == "DOCTOR" and db.scalar(select(Doctor.id).where(Doctor.user_id == actor_id)) != entry.doctor_id:
        raise HTTPException(403, "Cannot complete another doctor's queue")
    if entry.status != "CALLED":
        raise HTTPException(409, "Only called entries can be completed")
    entry.status = "DONE"
    appointment = db.get(Appointment, entry.appointment_id)
    appointment.status = "COMPLETED"
    audit(db, actor_id, "COMPLETE", "queue_entry", entry.id,
          old={"status": "CALLED"}, new={"status": "DONE"})
    audit(db, actor_id, "COMPLETE", "appointment", appointment.id,
          old={"status": "BOOKED"}, new={"status": "COMPLETED"})
    db.commit()
    return entry

@app.post("/appointments/{appointment_id}/prescription", response_model=PrescriptionView, status_code=201)
def prescribe(appointment_id: int, data: PrescriptionCreate, db: Session = Depends(get_db),
              user: User = Depends(roles("DOCTOR"))):
    actor_id = user.id
    begin_write(db)
    appointment = db.get(Appointment, appointment_id)
    doctor_id = db.scalar(select(Doctor.id).where(Doctor.user_id == actor_id))
    if appointment is None:
        raise HTTPException(404, "Appointment not found")
    if appointment.doctor_id != doctor_id:
        raise HTTPException(403, "Cannot prescribe for another doctor's appointment")
    if appointment.status != "COMPLETED":
        raise HTTPException(409, "Complete the appointment before prescribing")
    if db.scalar(select(Prescription.id).where(Prescription.appointment_id == appointment_id)):
        raise HTTPException(409, "Prescription already exists")
    prescription = Prescription(appointment_id=appointment_id, doctor_id=doctor_id, notes=data.notes)
    db.add(prescription)
    db.flush()
    audit(db, actor_id, "PRESCRIBE", "prescription", prescription.id, new={"appointment_id": appointment_id})
    db.commit()
    return prescription

@app.get("/appointments/{appointment_id}/prescription", response_model=PrescriptionView)
def view_prescription(appointment_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    appointment = db.get(Appointment, appointment_id)
    if appointment is None:
        raise HTTPException(404, "Appointment not found")
    if user.role == "PATIENT":
        patient_id = db.scalar(select(Patient.id).where(Patient.user_id == user.id))
        allowed = appointment.patient_id == patient_id
    elif user.role == "DOCTOR":
        allowed = appointment.doctor_id == db.scalar(select(Doctor.id).where(Doctor.user_id == user.id))
    else:
        allowed = user.role == "ADMIN"
    if not allowed:
        raise HTTPException(403, "Insufficient permissions")
    prescription = db.scalar(select(Prescription).where(Prescription.appointment_id == appointment_id))
    if prescription is None:
        raise HTTPException(404, "Prescription not found")
    return prescription

@app.get("/admin/audit-logs", response_model=list[AuditView])
def audit_logs(db: Session = Depends(get_db), _: User = Depends(roles("ADMIN")),
               offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=100)):
    return db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).offset(offset).limit(limit)).all()
