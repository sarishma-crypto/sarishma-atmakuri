import sqlite3
from datetime import date, datetime
from pathlib import Path
import pytest
from alembic import command
from alembic.config import Config
from app.clinic_time import clinic_datetime, clinic_day


def test_clinic_timezone_conversion(monkeypatch):
    monkeypatch.setenv("CLINIC_TIMEZONE", "Asia/Kolkata")
    start = clinic_datetime(date(2030, 1, 7), datetime.strptime("09:00", "%H:%M").time())
    assert start == datetime(2030, 1, 7, 3, 30)
    assert clinic_day(start) == date(2030, 1, 7)


def test_migration_guards_direct_sql(tmp_path, monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    root = Path(__file__).resolve().parents[1]
    path = tmp_path / "schema.db"
    config = Config(str(root / "alembic.ini"))
    config.set_main_option("script_location", str(root / "migrations"))
    config.set_main_option("sqlalchemy.url", f"sqlite:///{path.as_posix()}")
    command.upgrade(config, "head")
    with sqlite3.connect(path) as db:
        db.execute("PRAGMA foreign_keys=ON")
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"users", "doctors", "patients", "schedules", "appointments", "queue_entries", "prescriptions", "audit_logs"} <= tables
        migrated_objects = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE sql IS NOT NULL AND name != 'alembic_version'")}
        with sqlite3.connect(":memory:") as snapshot:
            snapshot.executescript((root / "schema.sql").read_text(encoding="utf-8"))
            snapshot_objects = {row[0] for row in snapshot.execute("SELECT name FROM sqlite_master WHERE sql IS NOT NULL")}
        assert migrated_objects == snapshot_objects
        db.execute("INSERT INTO users (id,email,password_hash,role,active) VALUES (1,'a@example.com','hash','ADMIN',1)")
        db.execute("INSERT INTO users (id,email,password_hash,role,active) VALUES (2,'d@example.com','hash','DOCTOR',1)")
        db.execute("INSERT INTO users (id,email,password_hash,role,active) VALUES (3,'p@example.com','hash','PATIENT',1)")
        db.execute("INSERT INTO doctors (id,user_id,name,specialty) VALUES (1,2,'Doctor','General')")
        db.execute("INSERT INTO patients (id,user_id,name) VALUES (1,3,'Patient')")
        db.execute("INSERT INTO schedules (doctor_id,weekday,start_time,end_time,slot_minutes) VALUES (1,0,'09:00:00','10:00:00',30)")
        with pytest.raises(sqlite3.IntegrityError, match="overlapping schedule"):
            db.execute("INSERT INTO schedules (doctor_id,weekday,start_time,end_time,slot_minutes) VALUES (1,0,'09:30:00','11:00:00',30)")
        db.execute("INSERT INTO appointments (doctor_id,patient_id,starts_at,ends_at,status,created_at) VALUES (1,1,'2030-01-07 09:00:00','2030-01-07 09:30:00','BOOKED','2030-01-01')")
        with pytest.raises(sqlite3.IntegrityError, match="overlapping appointment"):
            db.execute("INSERT INTO appointments (doctor_id,patient_id,starts_at,ends_at,status,created_at) VALUES (1,1,'2030-01-07 09:15:00','2030-01-07 09:45:00','BOOKED','2030-01-01')")
        db.execute("INSERT INTO audit_logs (user_id,action,entity,entity_id,created_at) VALUES (1,'TEST','appointment',1,'2030-01-01')")
        with pytest.raises(sqlite3.IntegrityError, match="append-only"):
            db.execute("DELETE FROM audit_logs")
