from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import sessionmaker
from app.db import Base, get_db
from app.main import app
from app.models import Appointment, AuditLog, Doctor, Patient, User
from app.security import hash_password
from app.schemas import BookingCreate
from app.service import book
from fastapi import HTTPException

@pytest.fixture
def setup(tmp_path, monkeypatch):
    monkeypatch.setenv("APP_SECRET_KEY", "integration-test-secret-at-least-32-characters")
    engine = create_engine(f"sqlite:///{tmp_path / 'test.db'}", connect_args={"check_same_thread": False})
    @event.listens_for(engine, "connect")
    def fk(connection, _):
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=5000")
    Base.metadata.create_all(engine)
    sessions = sessionmaker(bind=engine, expire_on_commit=False)
    def override():
        with sessions() as db:
            yield db
    app.dependency_overrides[get_db] = override
    with sessions() as db:
        admin = User(email="admin@example.com", password_hash=hash_password("strong-password"), role="ADMIN")
        db.add(admin)
        db.commit()
    with TestClient(app) as client:
        yield client, sessions
    app.dependency_overrides.clear()
    engine.dispose()

def token(client, email, password):
    response = client.post("/auth/login", data={"username": email, "password": password})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}

def prepare(setup):
    client, sessions = setup
    admin = token(client, "admin@example.com", "strong-password")
    assert client.post("/auth/register", json={"email": "patient@example.com", "password": "patient-password", "name": "Patient A"}).status_code == 201
    patient = token(client, "patient@example.com", "patient-password")
    staff = client.post("/admin/staff", json={"email": "doctor@example.com", "password": "doctor-password", "name": "Dr A", "role": "DOCTOR", "specialty": "General"}, headers=admin)
    assert staff.status_code == 201, staff.text
    doctor = token(client, "doctor@example.com", "doctor-password")
    with sessions() as db:
        doctor_id = db.scalar(select(Doctor.id))
        patient_id = db.scalar(select(Patient.id))
    return client, sessions, admin, patient, doctor, doctor_id, patient_id

def next_monday():
    now = datetime.now(timezone.utc)
    days = (7 - now.weekday()) % 7 or 7
    return (now + timedelta(days=days)).replace(hour=9, minute=0, second=0, microsecond=0)

def test_booking_conflict_and_cancel(setup):
    client, sessions, admin, patient, doctor, doctor_id, patient_id = prepare(setup)
    schedule = client.post(f"/admin/doctors/{doctor_id}/schedules", json={"weekday": 0, "start_time": "09:00", "end_time": "10:00", "slot_minutes": 30}, headers=admin)
    assert schedule.status_code == 201, schedule.text
    start = next_monday()
    payload = {"doctor_id": doctor_id, "starts_at": start.isoformat(), "ends_at": (start + timedelta(minutes=30)).isoformat()}
    slots = client.get(f"/doctors/{doctor_id}/available-slots", params={"day": start.date().isoformat()}, headers=patient)
    assert slots.status_code == 200 and len(slots.json()) == 2
    booked = client.post("/appointments", json=payload, headers=patient)
    assert booked.status_code == 201, booked.text
    assert client.post("/appointments", json=payload, headers=patient).status_code == 409
    assert len(client.get(f"/doctors/{doctor_id}/available-slots", params={"day": start.date().isoformat()}, headers=patient).json()) == 1
    assert client.post(f"/appointments/{booked.json()['id']}/cancel", headers=patient).status_code == 200
    assert client.post("/appointments", json=payload, headers=patient).status_code == 201
    with sessions() as db:
        assert db.scalar(select(AuditLog.id).where(AuditLog.action == "CANCEL")) is not None

def test_auth_and_patient_isolation(setup):
    client, sessions, admin, patient, doctor, doctor_id, patient_id = prepare(setup)
    assert client.get("/appointments").status_code == 401
    assert client.get("/").status_code == 200
    assert "Careflow" in client.get("/static/index.html").text
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/auth/me", headers=patient).json()["role"] == "PATIENT"
    assert client.get("/doctors/me", headers=doctor).json()["id"] == doctor_id
    assert client.get("/doctors/me", headers=patient).status_code == 403
    assert client.get("/patients", headers=patient).status_code == 403
    assert client.get("/patients", headers=admin).json()[0]["id"] == patient_id
    assert client.post("/admin/staff", json={}, headers=patient).status_code == 403
    other = client.post("/auth/register", json={"email": "other@example.com", "password": "another-password", "name": "Other"})
    assert other.status_code == 201
    with sessions() as db:
        other_id = db.scalar(select(Patient.id).where(Patient.name == "Other"))
    start = next_monday()
    payload = {"doctor_id": doctor_id, "patient_id": other_id, "starts_at": start.isoformat(), "ends_at": (start + timedelta(minutes=30)).isoformat()}
    assert client.post("/appointments", json=payload, headers=patient).status_code == 403

def test_queue_transition_and_prescription(setup):
    client, sessions, admin, patient, doctor, doctor_id, patient_id = prepare(setup)
    with sessions() as db:
        today = datetime.now(timezone.utc).replace(hour=12, minute=0, second=0, microsecond=0).replace(tzinfo=None)
        appointment = Appointment(doctor_id=doctor_id, patient_id=patient_id, starts_at=today, ends_at=today + timedelta(minutes=30), status="BOOKED")
        db.add(appointment)
        db.commit()
        appointment_id = appointment.id
    check = client.post(f"/appointments/{appointment_id}/check-in", headers=admin)
    assert check.status_code == 201, check.text
    assert client.post(f"/appointments/{appointment_id}/check-in", headers=admin).status_code == 409
    called = client.post(f"/queue/{doctor_id}/call-next", headers=doctor)
    assert called.status_code == 200, called.text
    assert client.post(f"/queue/{doctor_id}/call-next", headers=doctor).status_code == 409
    complete = client.post(f"/queue/{called.json()['id']}/complete", headers=doctor)
    assert complete.status_code == 200
    prescription = client.post(f"/appointments/{appointment_id}/prescription", json={"notes": "Rest and fluids"}, headers=doctor)
    assert prescription.status_code == 201, prescription.text
    assert client.get(f"/appointments/{appointment_id}/prescription", headers=patient).status_code == 200
    with sessions() as db:
        assert db.get(Appointment, appointment_id).status == "COMPLETED"
        assert db.scalar(select(AuditLog.id).where(AuditLog.action == "PRESCRIBE")) is not None

def test_concurrent_bookings_allow_only_one(setup):
    client, sessions, admin, patient, doctor, doctor_id, patient_id = prepare(setup)
    assert client.post(f"/admin/doctors/{doctor_id}/schedules", json={"weekday": 0, "start_time": "09:00", "end_time": "10:00", "slot_minutes": 30}, headers=admin).status_code == 201
    start = next_monday()
    data = BookingCreate(doctor_id=doctor_id, starts_at=start, ends_at=start + timedelta(minutes=30))
    with sessions() as db:
        actor_id = db.scalar(select(Patient.user_id).where(Patient.id == patient_id))
    def attempt(_):
        with sessions() as db:
            try:
                book(db, data, patient_id, actor_id)
                return 201
            except HTTPException as exc:
                return exc.status_code
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(attempt, range(2)))
    assert sorted(results) == [201, 409]
    with sessions() as db:
        assert len(db.scalars(select(Appointment)).all()) == 1

def test_staff_booking_and_clinic_timezone(setup, monkeypatch):
    monkeypatch.setenv("CLINIC_TIMEZONE", "Asia/Kolkata")
    client, sessions, admin, patient, doctor, doctor_id, patient_id = prepare(setup)
    assert client.get("/config").json() == {"timezone": "Asia/Kolkata"}
    created = client.post(f"/admin/doctors/{doctor_id}/schedules", json={
        "weekday": 0, "start_time": "09:00", "end_time": "10:00", "slot_minutes": 30
    }, headers=admin)
    assert created.status_code == 201, created.text
    assert len(client.get("/admin/schedules", headers=admin).json()) == 1
    clinic_monday = next_monday().date()
    slots = client.get(f"/doctors/{doctor_id}/available-slots", params={"day": clinic_monday.isoformat()}, headers=admin)
    assert slots.status_code == 200 and len(slots.json()) == 2
    assert slots.json()[0]["starts_at"].endswith("03:30:00")
    booking = client.post("/appointments", json={
        "doctor_id": doctor_id, "patient_id": patient_id,
        "starts_at": slots.json()[0]["starts_at"] + "Z",
        "ends_at": slots.json()[0]["ends_at"] + "Z",
    }, headers=admin)
    assert booking.status_code == 201, booking.text
    assert client.get("/patients", headers=doctor).json()[0]["id"] == patient_id
    assert client.get("/appointments", headers=patient).json()[0]["id"] == booking.json()["id"]
