-- Reference snapshot generated from Alembic migrations.
-- Use `alembic upgrade head` for a real installation.
PRAGMA foreign_keys=ON;

CREATE TABLE appointments (
	id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	starts_at DATETIME NOT NULL, 
	ends_at DATETIME NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CHECK (ends_at > starts_at), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id)
);

CREATE TABLE audit_logs (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	action VARCHAR(80) NOT NULL, 
	entity VARCHAR(80) NOT NULL, 
	entity_id INTEGER NOT NULL, 
	old_value TEXT, 
	new_value TEXT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);

CREATE TABLE doctors (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	specialty VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	UNIQUE (user_id)
);

CREATE TABLE patients (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	UNIQUE (user_id)
);

CREATE TABLE prescriptions (
	id INTEGER NOT NULL, 
	appointment_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	notes TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(appointment_id) REFERENCES appointments (id), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	UNIQUE (appointment_id)
);

CREATE TABLE queue_entries (
	id INTEGER NOT NULL, 
	appointment_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	checked_in_at DATETIME NOT NULL, 
	called_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(appointment_id) REFERENCES appointments (id), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	UNIQUE (appointment_id)
);

CREATE TABLE schedules (
	id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	weekday INTEGER NOT NULL, 
	start_time TIME NOT NULL, 
	end_time TIME NOT NULL, 
	slot_minutes INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	CHECK (slot_minutes > 0), 
	CHECK (weekday BETWEEN 0 AND 6), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id)
);

CREATE TABLE users (
	id INTEGER NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id)
);

CREATE INDEX ix_appointments_doctor_id ON appointments (doctor_id);

CREATE INDEX ix_appointments_patient_id ON appointments (patient_id);

CREATE INDEX ix_appointments_starts_at ON appointments (starts_at);

CREATE INDEX ix_queue_entries_doctor_id ON queue_entries (doctor_id);

CREATE INDEX ix_schedules_doctor_id ON schedules (doctor_id);

CREATE UNIQUE INDEX ix_users_email ON users (email);

CREATE TRIGGER appointments_insert_guard BEFORE INSERT ON appointments
        WHEN NEW.status NOT IN ('BOOKED','CANCELLED','COMPLETED') OR
             (NEW.status != 'CANCELLED' AND EXISTS (
               SELECT 1 FROM appointments a WHERE a.doctor_id = NEW.doctor_id
               AND a.status != 'CANCELLED' AND a.starts_at < NEW.ends_at AND a.ends_at > NEW.starts_at))
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping appointment'); END;

CREATE TRIGGER appointments_update_guard BEFORE UPDATE ON appointments
        WHEN NEW.status NOT IN ('BOOKED','CANCELLED','COMPLETED') OR
             (NEW.status != OLD.status AND NOT (
               OLD.status = 'BOOKED' AND NEW.status IN ('CANCELLED','COMPLETED'))) OR
             (NEW.status != 'CANCELLED' AND EXISTS (
               SELECT 1 FROM appointments a WHERE a.id != OLD.id AND a.doctor_id = NEW.doctor_id
               AND a.status != 'CANCELLED' AND a.starts_at < NEW.ends_at AND a.ends_at > NEW.starts_at))
        BEGIN SELECT RAISE(ABORT, 'invalid transition or overlapping appointment'); END;

CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
                 BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END;

CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs
                 BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END;

CREATE TRIGGER queue_insert_guard BEFORE INSERT ON queue_entries
        WHEN NEW.status != 'WAITING' OR NEW.doctor_id != (
          SELECT doctor_id FROM appointments WHERE id = NEW.appointment_id)
        BEGIN SELECT RAISE(ABORT, 'invalid queue entry'); END;

CREATE TRIGGER queue_update_guard BEFORE UPDATE ON queue_entries
        WHEN NEW.doctor_id != OLD.doctor_id OR NEW.appointment_id != OLD.appointment_id OR
             NOT ((OLD.status = NEW.status) OR (OLD.status = 'WAITING' AND NEW.status = 'CALLED') OR
                  (OLD.status = 'CALLED' AND NEW.status = 'DONE'))
        BEGIN SELECT RAISE(ABORT, 'invalid queue transition'); END;

CREATE TRIGGER schedules_insert_guard BEFORE INSERT ON schedules
        WHEN NEW.end_time <= NEW.start_time OR EXISTS (
          SELECT 1 FROM schedules s WHERE s.doctor_id = NEW.doctor_id AND s.weekday = NEW.weekday
          AND s.start_time < NEW.end_time AND s.end_time > NEW.start_time)
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping schedule'); END;

CREATE TRIGGER schedules_update_guard BEFORE UPDATE ON schedules
        WHEN NEW.end_time <= NEW.start_time OR EXISTS (
          SELECT 1 FROM schedules s WHERE s.id != OLD.id AND s.doctor_id = NEW.doctor_id AND s.weekday = NEW.weekday
          AND s.start_time < NEW.end_time AND s.end_time > NEW.start_time)
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping schedule'); END;
