"""Make audit logs append-only.

Revision ID: c21106a8d54a
Revises: b29c2821c8cc
"""
from alembic import op

revision = "c21106a8d54a"
down_revision = "b29c2821c8cc"
branch_labels = None
depends_on = None

def upgrade():
    op.execute("""CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs
                 BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END""")
    op.execute("""CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
                 BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END""")

def downgrade():
    op.execute("DROP TRIGGER audit_logs_no_delete")
    op.execute("DROP TRIGGER audit_logs_no_update")
