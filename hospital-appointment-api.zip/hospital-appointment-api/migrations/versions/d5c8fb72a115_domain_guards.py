"""Enforce domain integrity for direct SQLite writers.

Revision ID: d5c8fb72a115
Revises: c21106a8d54a
"""
from alembic import op

revision = "d5c8fb72a115"
down_revision = "c21106a8d54a"
branch_labels = None
depends_on = None

TRIGGERS = {
    "appointments_insert_guard": """CREATE TRIGGER appointments_insert_guard BEFORE INSERT ON appointments
        WHEN NEW.status NOT IN ('BOOKED','CANCELLED','COMPLETED') OR
             (NEW.status != 'CANCELLED' AND EXISTS (
               SELECT 1 FROM appointments a WHERE a.doctor_id = NEW.doctor_id
               AND a.status != 'CANCELLED' AND a.starts_at < NEW.ends_at AND a.ends_at > NEW.starts_at))
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping appointment'); END""",
    "appointments_update_guard": """CREATE TRIGGER appointments_update_guard BEFORE UPDATE ON appointments
        WHEN NEW.status NOT IN ('BOOKED','CANCELLED','COMPLETED') OR
             (NEW.status != OLD.status AND NOT (
               OLD.status = 'BOOKED' AND NEW.status IN ('CANCELLED','COMPLETED'))) OR
             (NEW.status != 'CANCELLED' AND EXISTS (
               SELECT 1 FROM appointments a WHERE a.id != OLD.id AND a.doctor_id = NEW.doctor_id
               AND a.status != 'CANCELLED' AND a.starts_at < NEW.ends_at AND a.ends_at > NEW.starts_at))
        BEGIN SELECT RAISE(ABORT, 'invalid transition or overlapping appointment'); END""",
    "schedules_insert_guard": """CREATE TRIGGER schedules_insert_guard BEFORE INSERT ON schedules
        WHEN NEW.end_time <= NEW.start_time OR EXISTS (
          SELECT 1 FROM schedules s WHERE s.doctor_id = NEW.doctor_id AND s.weekday = NEW.weekday
          AND s.start_time < NEW.end_time AND s.end_time > NEW.start_time)
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping schedule'); END""",
    "schedules_update_guard": """CREATE TRIGGER schedules_update_guard BEFORE UPDATE ON schedules
        WHEN NEW.end_time <= NEW.start_time OR EXISTS (
          SELECT 1 FROM schedules s WHERE s.id != OLD.id AND s.doctor_id = NEW.doctor_id AND s.weekday = NEW.weekday
          AND s.start_time < NEW.end_time AND s.end_time > NEW.start_time)
        BEGIN SELECT RAISE(ABORT, 'invalid or overlapping schedule'); END""",
    "queue_insert_guard": """CREATE TRIGGER queue_insert_guard BEFORE INSERT ON queue_entries
        WHEN NEW.status != 'WAITING' OR NEW.doctor_id != (
          SELECT doctor_id FROM appointments WHERE id = NEW.appointment_id)
        BEGIN SELECT RAISE(ABORT, 'invalid queue entry'); END""",
    "queue_update_guard": """CREATE TRIGGER queue_update_guard BEFORE UPDATE ON queue_entries
        WHEN NEW.doctor_id != OLD.doctor_id OR NEW.appointment_id != OLD.appointment_id OR
             NOT ((OLD.status = NEW.status) OR (OLD.status = 'WAITING' AND NEW.status = 'CALLED') OR
                  (OLD.status = 'CALLED' AND NEW.status = 'DONE'))
        BEGIN SELECT RAISE(ABORT, 'invalid queue transition'); END""",
}

def upgrade():
    for statement in TRIGGERS.values():
        op.execute(statement)

def downgrade():
    for name in reversed(TRIGGERS):
        op.execute(f"DROP TRIGGER {name}")
