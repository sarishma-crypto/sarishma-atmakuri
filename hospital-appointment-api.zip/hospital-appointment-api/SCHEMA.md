# Database schema

The live schema is managed by Alembic in `migrations/`. [schema.sql](schema.sql) is a readable SQL snapshot generated from a fresh migrated database. It has eight application tables plus Alembic's `alembic_version` table.

```mermaid
erDiagram
    users ||--o| doctors : has
    users ||--o| patients : has
    users ||--o{ audit_logs : acts
    doctors ||--o{ schedules : works
    doctors ||--o{ appointments : attends
    patients ||--o{ appointments : books
    appointments ||--o| queue_entries : checks_in
    appointments ||--o| prescriptions : receives
    doctors ||--o{ queue_entries : calls
    doctors ||--o{ prescriptions : writes
```

| Table | Purpose | Main columns and rules |
|---|---|---|
| `users` | Login identity and role | Unique `email`, bcrypt `password_hash`, `role`, `active`. Roles are `ADMIN`, `RECEPTIONIST`, `DOCTOR`, `PATIENT`. |
| `doctors` | Doctor profile | Unique `user_id` FK to `users`, `name`, `specialty`. |
| `patients` | Patient profile | Unique `user_id` FK to `users`, `name`. |
| `schedules` | Weekly doctor hours | `doctor_id` FK, `weekday` 0–6 (Monday–Sunday), local `start_time`, `end_time`, `slot_minutes`. Overlapping hours for one doctor and weekday are rejected by API and trigger. |
| `appointments` | Reserved doctor/patient interval | `doctor_id`, `patient_id`, UTC `starts_at` and `ends_at`, `status`, `created_at`. `ends_at > starts_at`. Active overlaps for one doctor are rejected by API and trigger. |
| `queue_entries` | One check-in per appointment | Unique `appointment_id`, `doctor_id`, `status`, UTC `checked_in_at`, `called_at`. Doctor must match the appointment. |
| `prescriptions` | Clinical notes after completion | Unique `appointment_id`, `doctor_id`, `notes`, UTC `created_at`. Only the treating doctor may create one through the API. |
| `audit_logs` | State change history | `user_id`, `action`, `entity`, `entity_id`, JSON text `old_value` and `new_value`, UTC `created_at`. SQLite triggers reject updates and deletes. |

All foreign keys are enabled on application connections. The API stores timestamps as naive SQLAlchemy `DateTime` values that represent UTC. Incoming appointment timestamps must include an explicit UTC offset. Weekly hours use the configured clinic timezone. The client converts slot timestamps for display.

## State transitions

```text
Appointment: BOOKED -> CANCELLED
             BOOKED -> COMPLETED

Queue:       WAITING -> CALLED -> DONE
```

An appointment enters the queue only after check-in. The queue is scoped to the current clinic day. Calling the next patient is atomic and follows check-in order. Prescriptions require a completed appointment. Audit rows are written in the same transaction as each API state change.

## Why both API checks and database triggers?

API checks return clear errors to users. SQLite triggers protect the database if another script or direct SQL client writes to it. Migrations add the append-only audit guard, overlap guards, and queue transition guards. They are part of the installed schema and are tested in `tests/test_migrations.py`.
