# API and access

The frontend uses these routes. Open `/docs` on a running instance for request and response examples and the live OpenAPI schema. All routes except `/`, `/static/*`, `/config`, `/auth/register`, and `/auth/login` require a bearer token.

| Area | Method and path | Allowed roles | Purpose |
|---|---|---|---|
| Auth | `POST /auth/register` | Public | Register a patient account. |
| Auth | `POST /auth/login` | Public | OAuth2 password form; returns a one-hour JWT. Username is the email address. |
| Auth | `GET /auth/me` | Any signed-in user | Current account. |
| Clinic | `GET /config` | Public | Clinic timezone. |
| Doctors | `GET /doctors` | Any signed-in user | Paginated doctors; optional specialty filter. |
| Doctors | `GET /doctors/me` | Doctor | Own doctor profile. |
| Doctors | `GET /doctors/{id}/schedules` | Any signed-in user | Weekly hours. |
| Doctors | `GET /doctors/{id}/available-slots?day=YYYY-MM-DD` | Any signed-in user | Unbooked slots for a clinic-local date. |
| Patients | `GET /patients` | Admin, receptionist, doctor | Admin/reception see patients; doctors see only patients with their appointments. |
| Admin | `POST /admin/staff` | Admin | Add doctor or receptionist account. |
| Admin | `POST /admin/doctors/{id}/schedules` | Admin | Add weekly hours. |
| Admin | `GET /admin/schedules` | Admin | All weekly hours. |
| Admin | `GET /admin/audit-logs` | Admin | Recent audit rows, newest first. |
| Appointments | `POST /appointments` | Patient, receptionist, admin | Book an open slot. Staff must specify `patient_id`; patients may book only for themselves. |
| Appointments | `GET /appointments` | Any signed-in user | Patient and doctor views are scoped to themselves; admin/reception see all. Supports status, sort, offset, and limit. |
| Appointments | `POST /appointments/{id}/cancel` | Owning patient, receptionist, admin | Cancel an unchecked-in booking. |
| Queue | `POST /appointments/{id}/check-in` | Receptionist, admin | Put today's booking in the waiting queue. |
| Queue | `GET /queue/{doctor_id}` | Doctor (own), receptionist, admin | Current clinic-day queue. |
| Queue | `POST /queue/{doctor_id}/call-next` | Doctor (own), receptionist, admin | Call the oldest waiting patient. |
| Queue | `POST /queue/{entry_id}/complete` | Doctor (own), admin | Finish the visit and appointment. |
| Prescription | `POST /appointments/{id}/prescription` | Treating doctor | Write notes after completion, once per appointment. |
| Prescription | `GET /appointments/{id}/prescription` | Owning patient, treating doctor, admin | View notes. |

**Error behavior:** invalid input returns `422`, business rule failures return `400` or `409`, missing records return `404`, invalid login/token returns `401`, and role or ownership failures return `403`.

**Pagination:** list routes limit their response sizes. The frontend currently loads the first 100 records for its simple clinic screens; the API provides `offset` and `limit` on the larger lists. For a large clinic, add server-side search and pagination to the frontend before relying on it for day-to-day operations.
