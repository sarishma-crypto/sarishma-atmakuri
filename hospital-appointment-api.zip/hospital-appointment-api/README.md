# Careflow — Hospital Appointment & Queue Management

A local, full-stack FastAPI + SQLite project. The frontend covers patient booking, staff booking, doctor hours, check-in, live queues, prescriptions, and admin audit history. The backend uses JWT login, role checks, SQLAlchemy 2, Alembic migrations, SQLite transaction locks, database triggers, and pytest.

Start here. The database design is in [SCHEMA.md](SCHEMA.md), the exact SQL snapshot is in [schema.sql](schema.sql), and the endpoint and role list is in [API.md](API.md).

## 1. Prerequisites

- Python 3.11 or 3.12 (64-bit recommended). Check with `python --version`.
- A terminal: PowerShell on Windows or a shell on macOS/Linux.
- No separate database server, Node.js, or frontend build step is needed.

If Windows reports that `python.exe` has the wrong architecture or opens the Microsoft Store, install a compatible Python from [python.org](https://www.python.org/downloads/) and use that Python executable for the commands below.

## 2. Extract and enter the project

Unzip `hospital-appointment-api.zip`. Open a terminal **inside the extracted `hospital-appointment-api` folder**, where `requirements.txt` and `alembic.ini` are located.

PowerShell example:

```powershell
cd "C:\path\to\hospital-appointment-api"
```

macOS/Linux example:

```bash
cd /path/to/hospital-appointment-api
```

## 3. Create a virtual environment and install dependencies

PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

The commands use the virtual environment directly, so activation is optional.

## 4. Set the app secret and clinic timezone

The secret signs one-hour login tokens. Generate it in the same terminal that will start the server. Keep it private and reuse the same value after restarts if you want existing sessions to stay valid.

PowerShell:

```powershell
$env:APP_SECRET_KEY = (& .\.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(48))")
$env:CLINIC_TIMEZONE = "Asia/Kolkata"
```

macOS/Linux:

```bash
export APP_SECRET_KEY="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export CLINIC_TIMEZONE="Asia/Kolkata"
```

`CLINIC_TIMEZONE` is optional; the default is `UTC`. Use an IANA timezone name such as `Asia/Kolkata`, `Europe/London`, or `America/New_York`. Weekly doctor hours, booking dates, and check-in days use this clinic timezone. Appointment timestamps in the database remain UTC.
Choose the timezone before adding schedules or bookings, and keep it the same afterward.

For a different SQLite file, set `DATABASE_URL` before the migration and server commands. Example: `sqlite:///./hospital.db`. If omitted, the app uses `hospital.db` in the current working directory.

## 5. Create the database

PowerShell:

```powershell
.\.venv\Scripts\alembic.exe upgrade head
```

macOS/Linux:

```bash
.venv/bin/alembic upgrade head
```

This creates the tables, indexes, and protection triggers. Run it again after pulling an updated version of this project. **Do not import `schema.sql` into the same database**; it is a reference snapshot of the Alembic result.

## 6. Create the first admin

PowerShell:

```powershell
.\.venv\Scripts\python.exe -m app.bootstrap_admin admin@example.com
```

macOS/Linux:

```bash
.venv/bin/python -m app.bootstrap_admin admin@example.com
```

Enter and confirm a password when prompted. Use your own valid email address instead of the example. The password must have at least 12 characters and at most 72 UTF-8 bytes. The bootstrap command refuses an email that already exists. Passwords are not passed as command-line arguments.

## 7. Start the server

PowerShell:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

macOS/Linux:

```bash
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

The terminal stays open while the app runs. Visit `http://127.0.0.1:8000/` for the frontend. `http://127.0.0.1:8000/docs` has interactive API documentation. Use `Ctrl+C` to stop the server. `127.0.0.1` is local to your computer; other people cannot use your server through this address.

## 8. Set up and use the clinic

1. Sign in as the admin created in step 6.
2. In **Clinic setup**, add a doctor (name, email, specialty, and a temporary password). Add a receptionist if needed. Give each staff member their own login details through a secure channel.
3. In **Set doctor hours**, choose the doctor, weekday, start/end times, and appointment length. These are weekly hours in the `CLINIC_TIMEZONE` from step 4. Existing schedules for the same doctor and weekday cannot overlap.
4. A patient selects **Create patient account** on the sign-in page and registers. A patient can then use **Book a visit** to choose a doctor, date, and open time. Admins and receptionists can use **Book for patient** after that patient has registered.
5. On the appointment day, the receptionist or admin opens **Appointments** and selects **Check in**. The entry moves to `WAITING` in the doctor’s queue.
6. The doctor, receptionist, or admin opens **Live queue** and selects **Call next patient**. Only one patient per doctor can be `CALLED` at a time. The doctor or admin selects **Complete visit**.
7. The doctor writes a prescription after completion. They can return to **My appointments** and select **Prescription** later. The patient can view it from **My appointments**.
8. Admins can inspect recent state changes in **Audit log**.

Booking and queue calls are serialized with `BEGIN IMMEDIATE`. The application checks for overlaps before saving, and SQLite triggers independently reject overlapping appointments and schedules. Cancelling a booking makes the slot available again.

## 9. Verify the installation

Stop the server or open another terminal in the same project folder. Set the same environment variables from step 4 when using a new terminal, then run:

PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

macOS/Linux:

```bash
.venv/bin/python -m pytest -q
```

You can also check the HTTP response without signing in:

```powershell
Invoke-WebRequest http://127.0.0.1:8000/config
```

That route returns the configured clinic timezone. The tests use temporary databases and do not change `hospital.db`.

## 10. Restart, update, and back up

- To restart, return to the project folder, set the same `APP_SECRET_KEY` and `CLINIC_TIMEZONE`, then run the server command in step 7. A new secret makes old tokens invalid and users must sign in again.
- After a code update, stop the server, install updated requirements, run `alembic upgrade head`, and start it again.
- Back up `hospital.db` while the server is stopped. Keep the backup private: it contains account and prescription records. Do not add it to a ZIP you share.
- To use another port, change `--port 8000` to a free port and use that port in the frontend URL.

## Project layout

```text
app/main.py             API routes and static frontend serving
app/models.py           SQLAlchemy tables
app/schemas.py          Request and response models
app/service.py          Booking, slot, and queue rules
app/clinic_time.py      Clinic timezone conversion
app/security.py         JWT, bcrypt, and role checks
app/static/             Frontend HTML, CSS, and JavaScript
migrations/             Alembic schema changes and triggers
tests/                  API, concurrency, timezone, and migration checks
schema.sql              Readable snapshot of the migrated SQLite schema
```

## Scope

This is a local educational system, not a certified hospital record system. A real clinical deployment still needs organization-specific privacy, consent, retention, recovery, monitoring, access review, and regulatory work. The project deliberately does not send email or SMS, process payments, or integrate with an EHR.
